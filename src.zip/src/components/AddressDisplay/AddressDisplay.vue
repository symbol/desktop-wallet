<template>
  <span>{{ descriptor }}</span>
</template>

<script lang="ts">
import {AddressDisplayTs} from './AddressDisplayTs'

export default class AddressDisplay extends AddressDisplayTs {}
</script>
