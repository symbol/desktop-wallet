<template>
  <div class="page-wrapper">
    <router-view />
  </div>
</template>

<script lang="ts">
import Vue from 'vue'
import './RouterPage.less'

export default class Login extends Vue {}
</script>
