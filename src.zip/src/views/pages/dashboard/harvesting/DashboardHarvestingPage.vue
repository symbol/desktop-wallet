<template>
  <div class="harvesting-container secondary_page_animate">
    <div class="left-container scroll">
      Harvesting History
    </div>

    <div class="right-container">
      Harvesting Details
    </div>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import {DashboardHarvestingPageTs} from './DashboardHarvestingPageTs'
import './DashboardHarvestingPage.less'

export default class DashboardHarvestingPage extends DashboardHarvestingPageTs {}
</script>
