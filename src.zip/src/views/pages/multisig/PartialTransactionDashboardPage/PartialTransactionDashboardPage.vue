<template>
  <div>PartialTransactionDashboardPage</div>
</template>

<script>
// external dependencies
import {Component, Vue} from 'vue-property-decorator'

@Component
export default class PartialTransactionDashboardPage extends Vue {}
</script>
